define([
    // Any providers required here will be bundled in jwplayer.js embed
    //  because they are commented out, html5 and flash js will be split into seperate files starting in 7.5.0
    // 'providers/html5',
    // 'providers/flash'
], function() {

    return {
        // html5: html5,
        // flash: flash
    };
});
