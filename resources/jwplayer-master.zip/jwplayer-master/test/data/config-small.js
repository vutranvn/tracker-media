define({
    file: '//playertest.longtailvideo.com/barsandtone.mp4'
});
