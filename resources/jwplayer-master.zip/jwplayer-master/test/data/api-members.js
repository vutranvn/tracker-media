define([
    'utils/underscore'
], function(_) {
    return {
        id: '',
        version: '',
        _qoe: {},
        utils: {},
        Events: {},
        _: _
    };
});
