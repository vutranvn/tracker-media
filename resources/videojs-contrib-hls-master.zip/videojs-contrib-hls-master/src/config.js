export default {
  GOAL_BUFFER_LENGTH: 30
};
